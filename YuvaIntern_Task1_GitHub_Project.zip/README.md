# Yuva Intern Data Scientist Internship – Task 1
## Wine Class Prediction and Data Analysis

This repository contains the practical code and analysis supporting Tasks 1–6.

### Tools
Python, pandas, NumPy, Matplotlib, scikit-learn.

### Run
pip install pandas numpy matplotlib scikit-learn
python main.py

The dataset is loaded through scikit-learn's Wine dataset utility.
